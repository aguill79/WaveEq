#!/bin/bash
# add executables at this point in shell script
/bin/bash ./gen_gif.sh 512 100
#./wave_untiled 2048 100
